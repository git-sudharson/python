#include <iostream>
#include "var.h"
using namespace std;

int main() {

  int div;
   
 

  // sum of two numbers in stored in variable sumOfTwoNumbers
  div = var_a / var_b;

  // prints sum 
  cout << var_a << " / " <<  var_b << " = " << div;     

  return 0;
}
