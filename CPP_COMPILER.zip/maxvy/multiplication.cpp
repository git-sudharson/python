#include <iostream>
#include "var.h"

using namespace std;

int main() 
{
int mul;
mul = var_a * var_b;
cout<< var_a <<" * "<< var_b <<"= "<< mul <<endl;
return 0;

}
