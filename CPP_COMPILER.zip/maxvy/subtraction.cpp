#include <iostream>
#include "var.h"
using namespace std;

int main() {

  int  sum;
    
 

  // sum of two numbers in stored in variable sumOfTwoNumbers
  sum = var_a - var_b;

  // prints sum 
  cout << var_a << " - " << var_b << " = " << sum;     

  return 0;
}
