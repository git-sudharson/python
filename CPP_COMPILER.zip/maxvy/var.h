#ifndef var
#define var


int var_a = 10, var_b = 2,  var_c = 10;

#endif // var
