#include <iostream>
using namespace std;

int main() {

  int first_number ,second_number, sum;
    first_number = 50;
    second_number = 60;
 

  // sum of two numbers in stored in variable sumOfTwoNumbers
  sum = first_number + second_number;

  // prints sum 
  cout << first_number << " + " <<  second_number << " = " << sum;     

  return 0;
}