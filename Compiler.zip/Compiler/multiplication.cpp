#include <iostream>

using namespace std;

int main() 
{

cout<<" 1 1 3 5 7"<<endl;
return 0;

}