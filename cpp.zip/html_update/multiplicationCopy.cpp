#include <iostream>

using namespace std;

int main() 
{

int a=4 ;

int b=5 ;

/*cout<<a*b;

*/
cout<<"hello world "<<endl;
return 0;

}